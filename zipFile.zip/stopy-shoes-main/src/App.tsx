import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { CartProvider } from "@/contexts/CartContext";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import AIChatWidget from "@/components/chat/AIChatWidget";
import Index from "./pages/Index";
import Products from "./pages/Products";
import ProductDetail from "./pages/ProductDetail";
import Cart from "./pages/Cart";
import Checkout from "./pages/Checkout";
import OrderSuccess from "./pages/OrderSuccess";
import Wishlist from "./pages/Wishlist";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import NewArrivals from "./pages/NewArrivals";
import DiscountItems from "./pages/DiscountItems";
import FlashSalePage from "./pages/FlashSalePage";
import MyPage from "./pages/MyPage";
import MyOrders from "./pages/MyOrders";
import MyAddresses from "./pages/MyAddresses";
import MyReturns from "./pages/MyReturns";
import MyReviews from "./pages/MyReviews";
import MySettings from "./pages/MySettings";
import TrackOrder from "./pages/TrackOrder";
import ReturnPolicy from "./pages/ReturnPolicy";
import Contact from "./pages/Contact";
import FAQ from "./pages/FAQ";
import NotFound from "./pages/NotFound";
import AdminLogin from "./pages/admin/AdminLogin";
import DeveloperPage from "./pages/DeveloperPage";
import AdminLayout from "./pages/admin/AdminLayout";
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminProducts from "./pages/admin/AdminProducts";
import AdminCategories from "./pages/admin/AdminCategories";
import AdminOrders from "./pages/admin/AdminOrders";
import AdminCustomers from "./pages/admin/AdminCustomers";
import AdminBanners from "./pages/admin/AdminBanners";
import AdminPromos from "./pages/admin/AdminPromos";
import AdminReturns from "./pages/admin/AdminReturns";
import AdminChat from "./pages/admin/AdminChat";
import AdminReviews from "./pages/admin/AdminReviews";
import AdminReports from "./pages/admin/AdminReports";
import AdminStockAlerts from "./pages/admin/AdminStockAlerts";
import AdminSettings from "./pages/admin/AdminSettings";
import AdminPayments from "./pages/admin/AdminPayments";
import AdminTodayOrders from "./pages/admin/AdminTodayOrders";
import AdminDelivery from "./pages/admin/AdminDelivery";
import AdminActivity from "./pages/admin/AdminActivity";
import AdminPaymentMethods from "./pages/admin/AdminPaymentMethods";
import AdminAiDiscounts from "./pages/admin/AdminAiDiscounts";
import AdminProductAnalytics from "./pages/admin/AdminProductAnalytics";
import AdminOrderChecklist from "./pages/admin/AdminOrderChecklist";
import AdminFormGenerator from "./pages/admin/AdminFormGenerator";
import AdminCityManager from "./pages/admin/AdminCityManager";
import AdminAiHelper from "./pages/admin/AdminAiHelper";
import AdminInventoryInsights from "./pages/admin/AdminInventoryInsights";
import AdminAiSiteManager from "./pages/admin/AdminAiSiteManager";
import AdminAiBannerCreator from "./pages/admin/AdminAiBannerCreator";
import Notifications from "./pages/Notifications";

const queryClient = new QueryClient();

const AdminGuard = ({ children }: { children: React.ReactNode }) => {
  const { isAdmin, loading } = useAuth();
  if (loading) return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  if (!isAdmin) return <Navigate to="/admin/login" replace />;
  return <>{children}</>;
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <AuthProvider>
        <CartProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/products" element={<Products />} />
              <Route path="/product/:id" element={<ProductDetail />} />
              <Route path="/cart" element={<Cart />} />
              <Route path="/checkout" element={<Checkout />} />
              <Route path="/order-success/:id" element={<OrderSuccess />} />
              <Route path="/wishlist" element={<Wishlist />} />
              <Route path="/login" element={<Login />} />
              <Route path="/signup" element={<Signup />} />
              <Route path="/new-arrivals" element={<NewArrivals />} />
              <Route path="/discount-items" element={<DiscountItems />} />
              <Route path="/flash-sale" element={<FlashSalePage />} />
              <Route path="/my-page" element={<MyPage />} />
              <Route path="/my-orders" element={<MyOrders />} />
              <Route path="/my-addresses" element={<MyAddresses />} />
              <Route path="/my-returns" element={<MyReturns />} />
              <Route path="/my-reviews" element={<MyReviews />} />
              <Route path="/my-settings" element={<MySettings />} />
              <Route path="/track-order" element={<TrackOrder />} />
              <Route path="/return-policy" element={<ReturnPolicy />} />
              <Route path="/contact" element={<Contact />} />
              <Route path="/faq" element={<FAQ />} />
              <Route path="/developer" element={<DeveloperPage />} />
              <Route path="/notifications" element={<Notifications />} />
              
              <Route path="/admin/login" element={<AdminLogin />} />
              <Route path="/admin" element={<AdminGuard><AdminLayout /></AdminGuard>}>
                <Route index element={<AdminDashboard />} />
                <Route path="products" element={<AdminProducts />} />
                <Route path="categories" element={<AdminCategories />} />
                <Route path="orders" element={<AdminOrders />} />
                <Route path="payments" element={<AdminPayments />} />
                <Route path="payment-methods" element={<AdminPaymentMethods />} />
                <Route path="today-orders" element={<AdminTodayOrders />} />
                <Route path="customers" element={<AdminCustomers />} />
                <Route path="banners" element={<AdminBanners />} />
                <Route path="promos" element={<AdminPromos />} />
                <Route path="reviews" element={<AdminReviews />} />
                <Route path="returns" element={<AdminReturns />} />
                <Route path="chat" element={<AdminChat />} />
                <Route path="reports" element={<AdminReports />} />
                <Route path="product-analytics" element={<AdminProductAnalytics />} />
                <Route path="ai-discounts" element={<AdminAiDiscounts />} />
                <Route path="order-checklist" element={<AdminOrderChecklist />} />
                <Route path="form-generator" element={<AdminFormGenerator />} />
                <Route path="delivery" element={<AdminDelivery />} />
                <Route path="stock-alerts" element={<AdminStockAlerts />} />
                <Route path="city-manager" element={<AdminCityManager />} />
                <Route path="ai-helper" element={<AdminAiHelper />} />
                <Route path="ai-site-manager" element={<AdminAiSiteManager />} />
                <Route path="ai-banner-creator" element={<AdminAiBannerCreator />} />
                <Route path="inventory" element={<AdminInventoryInsights />} />
                <Route path="activity" element={<AdminActivity />} />
                <Route path="settings" element={<AdminSettings />} />
              </Route>
              
              <Route path="*" element={<NotFound />} />
            </Routes>
            <AIChatWidget />
          </BrowserRouter>
        </CartProvider>
      </AuthProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
